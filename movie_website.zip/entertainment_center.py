# -*- coding: cp1252 -*-
# Lesson 3.4: Make Classes
# Mini-Project: Movies Website
# PEP8 Validated - http://pep8online.com/checkresult

# Class - Group of functions that can be used repeadedly as
# Instances - Events where a class is used
# __init__ - Initiatlize and is a constructor
# self - Object or instance being created

import fresh_tomatoes
import media


idiocracy = media.Movie("Idiocracy",
                        '''In 2005, average in every way private Joe Bowers
(Luke Wilson) is selected to take part in a secret military experiment to put
him in hibernation for a year along with a woman named Rita (Maya Rudolph).
The slumbering duo is forgotten when the base they are stored on is closed
down and are left in stasis until 2505. When they finally wake up, they
discover the average intelligence of humans has decreased so much that
Joe is now the smartest man in the world.''',
                        "http://ecx.images-amazon.com/images/I/51pLNnbThwL.\
_SY355_.jpg",
                        "https://www.youtube.com/watch_popup?v=clYwX8Z43zg")

# print (idiocracy.storyline) # print statement
# idiocracy.show_trailer() # show trailer method

dazed_and_confused = media.Movie("Dazed And Confused",
                                 '''This coming-of-age film follows the mayhem
of group of rowdy teenagers in Austin, Texas, celebrating the last day of high
school in 1976. The graduating class heads for a popular pool hall and joins
an impromptu keg party, however star football player Randall 'Pink' Floyd
(Jason London) has promised to focus on the championship game and abstain from
partying. Meanwhile, the incoming freshmen try to avoid being hazed by the
seniors, most notably the sadistic bully Fred O'Bannion (Ben Affleck).''',
                                 "http://ecx.images-amazon.com/images/I/51IfVf\
1owWL._SX200_QL80_.jpg",
                                 "https://www.youtube.com/watch_popup?v=3aQuvP\
lcB-8")

# print (dazed_and_confused.storyline) # print statement
# dazed_and_confused.show_trailer() # show trailer method

avatar = media.Movie("Avatar",
                     '''On the lush alien world of Pandora live the Na'vi,
beings who appear primitive but are highly evolved. Because the planet's
environment is poisonous, human/Na'vi hybrids, called Avatars, must link to
human minds to allow for free movement on Pandora. Jake Sully (Sam Worthington)
a paralyzed former Marine, becomes mobile again through one such Avatar and
falls in love with a Na'vi woman (Zoe Saldana). As a bond with her grows,
he is drawn into a battle for the survival of her world.''',
                     "http://cafmp.com/wp-content/uploads/2012/11/avatar\
.jpg",
                     "http://www.youtube.com/watch_popup?v=5PSNL1qE6VY")

# print (avatar.storyline) # print statement
# avatar.show_trailer() # show trailer method

interstellar = media.Movie("Interstellar",
                           '''Professor Brand (Michael Caine), a brilliant
NASA physicist, is working on plans to save mankind by transporting Earth's
population to a new home via a wormhole. But first, Brand must send former
NASA pilot Cooper (Matthew McConaughey) and a team of researchers through the
wormhole and across the galaxy to find out which of three planets could be
mankind's new home.''',
                           "http://cdn.hitfix.com/photos/5745371/Poster-art\
-for-Interstellar_event_main.jpg",
                           "http://www.youtube.com/watch_popup?v=0vxOhd4qlnA")

# print (interstellar.storyline) # print statement
# interstellar.show_trailer() # show trailer method

sirius = media.Movie("Sirius",
                     '''Sirius is a feature length documentary that follows
Dr. Steven Greer, an emergency room doctor turned UFO researcher, as he
struggles to disclose top secret information about classified energy &
propulsion techniques.''',
                     "http://www.giantfreakinrobot.com/wp-content/uploads\
/2013/04/sirius-poster.jpg",
                     "https://www.youtube.com/watch_popup?v=vOyf6KsOFKs")

# print (sirius.storyline) # print statement
# sirius.show_trailer() # show trailer method

network = media.Movie("Network",
                      '''In this lauded satire, veteran news anchorman
Howard Beale (Peter Finch) discovers that he's being put out to pasture, and
he's none too happy about it. After threatening to shoot himself on live
television, instead he launches into an angry televised rant, which turns
out to be a huge ratings boost for the UBS network. This stunt allows ambitious
producer Diana Christensen (Faye Dunaway) to develop even more outrageous
programming, a concept that she takes to unsettling extremes.''',
                      "http://images.losmovies.es/movie/network_1976.jpg",
                      "https://www.youtube.com/watch_popup?v=qnGgsJ26dao")

# print (network.storyline) # print statement
# network.show_trailer() # show trailer method

movies = [interstellar, avatar, dazed_and_confused, idiocracy, sirius, network]
fresh_tomatoes.open_movies_page(movies)

# print (media.Movie.VALID_RATINGS)
# print (media.Movie.__doc__)
